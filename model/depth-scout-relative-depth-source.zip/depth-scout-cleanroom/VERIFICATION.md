# Verification record

## Public-checkpoint model path

The standalone model-check script successfully downloaded and ran the unmodified `depth-anything/Depth-Anything-V2-Small-hf` checkpoint locally through the Transformers depth-estimation interface. It produced a 1600 × 1139 relative-depth output from a newly sourced rover-terrain test image that is stored outside this repository and is not packaged with the app.

The color visualization separated the bright sky, layered rock face, and foreground terrain into visibly different relative structures. This is a visual sanity check only. It does not establish physical depth accuracy on Mars, and the app records this limitation in both the interface and model-provenance documentation.

## Automated checks

The initial compile and unit-test run completed successfully: four tests passed for the display normalization and future backend-adapter boundary.

## Initial application interface

The standalone Streamlit interface loaded successfully with the local public-checkpoint and future-backend choices, the exact model identifier, Apache-2.0 license statement, no-fine-tuning disclosure, and relative-depth limitation visible before any image upload. The initial screen also explicitly states the clean-room separation from MARSBOUND and requires an image upload before inference.

## Live local inference and backend boundary

The independently sourced rover image was uploaded through the live interface, and the local unmodified public checkpoint completed inference. The app rendered the source image, relative-depth color and grayscale views, model identifier, Apache-2.0 license, and output limitation together.

Selecting **Future backend API** exposed the backend base-URL field. The UI boundary corresponds to the documented `POST /v1/relative-depth` contract and `BackendDepthClient`, confirming that a later backend move does not require redesigning the app’s display layer.
