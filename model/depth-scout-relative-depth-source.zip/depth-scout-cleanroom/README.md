# Depth Scout

Depth Scout is a **fresh, standalone relative-depth visualization app**. It uses the unmodified public `depth-anything/Depth-Anything-V2-Small-hf` checkpoint, which the official model card labels Apache-2.0. It is not derived from, connected to, or packaged with MARSBOUND.

> Depth Scout is for exploratory visual review. It does not measure Mars elevation or distance, identify terrain classes, detect hazards, estimate slope, or certify a landing decision.

## Run locally

Use a fresh Python environment. The first local inference downloads the cited public checkpoint from Hugging Face.

```bash
python3 -m pip install -r requirements.txt
streamlit run app.py
```

## Architecture

| Module | Role |
|---|---|
| `src/local_depth_anything.py` | Loads the unmodified public checkpoint locally. |
| `src/contracts.py` | Defines the model-agnostic relative-depth result contract. |
| `src/backend_adapter.py` | Calls a future `POST /v1/relative-depth` backend without changing the UI. |
| `src/visualization.py` | Converts relative model output into labeled display visualizations. |
| `API_CONTRACT.md` | Documents the future backend request and response. |

## Test

```bash
python3 -m unittest discover -s tests -v
python3 scripts/run_model_check.py path/to/image.jpg output/
```

## AegisLanding backend handoff

For the requested NSIC SW08 starter repository, use `integration/aegislanding_ml_engine.py` as a direct replacement for the backend’s `MLElevationAnalyzer` placeholder. The adapter matches the existing `engine=ml` upload route and keeps output to an attributed relative-depth visualization rather than inventing safe zones. See [INTEGRATION_AEGISLANDING.md](INTEGRATION_AEGISLANDING.md) for the three integration steps and an authenticated multipart smoke test; [requirements-backend.txt](requirements-backend.txt) locks the additional CPU inference dependencies.

## Attribution

See [MODEL_PROVENANCE.md](MODEL_PROVENANCE.md) for the exact model identifier, authors, source URLs, license, citation, and use boundary. The official model card describes this checkpoint for zero-shot depth estimation, not Mars-specific measurement. [1] [2]

## References

[1] [Depth Anything V2 Small official model card](https://huggingface.co/depth-anything/Depth-Anything-V2-Small-hf)

[2] [Depth Anything V2 official repository](https://github.com/DepthAnything/Depth-Anything-V2)
