"""Drop-in implementation for AegisLanding's backend/app/ml_engine.py.

Replace the starter repository's placeholder file with this module after the
team has approval to use the public pre-trained checkpoint. It matches the
existing MLElevationAnalyzer.analyze_terrain(bytes) interface and returns the
AssessmentResponse-compatible dictionary expected by backend/app/main.py.
"""

from __future__ import annotations

import base64
from io import BytesIO
from typing import Any

import cv2
import numpy as np
from PIL import Image

MODEL_ID = "depth-anything/Depth-Anything-V2-Small-hf"
MODEL_LICENSE = "Apache-2.0"
MAX_INPUT_WIDTH = 1600
BOUNDARY = (
    "Relative-depth visualization only; not a Mars elevation, distance, slope, "
    "hazard classification, landing-risk score, or safety decision."
)


def _resize_for_inference(image: Image.Image) -> Image.Image:
    if image.width <= MAX_INPUT_WIDTH:
        return image
    height = round(image.height * MAX_INPUT_WIDTH / image.width)
    return image.resize((MAX_INPUT_WIDTH, height), Image.Resampling.LANCZOS)


def _normalize_for_display(depth: np.ndarray) -> np.ndarray:
    finite = depth[np.isfinite(depth)]
    if finite.size == 0:
        raise ValueError("Model output contains no finite relative-depth values.")
    low, high = float(finite.min()), float(finite.max())
    if high - low < 1e-9:
        return np.zeros(depth.shape, dtype=np.uint8)
    return np.uint8(np.clip((depth - low) / (high - low), 0.0, 1.0) * 255)


def _as_data_url(image_bgr: np.ndarray) -> str:
    success, encoded = cv2.imencode(".jpg", image_bgr, [int(cv2.IMWRITE_JPEG_QUALITY), 90])
    if not success:
        raise ValueError("Could not encode the depth visualization.")
    data = base64.b64encode(encoded.tobytes()).decode("ascii")
    return f"data:image/jpeg;base64,{data}"


class MLElevationAnalyzer:
    """Public-checkpoint relative-depth adapter for AegisLanding's ML route.

    `safe_zones` is intentionally empty because relative depth alone cannot
    determine a safe landing zone. The caller can combine this image evidence
    with independently implemented risk logic later.
    """

    def __init__(self, lander_size_px: int = 30):
        self.lander_size = lander_size_px
        self._pipeline = None

    def _load_model(self):
        if self._pipeline is None:
            from transformers import pipeline

            self._pipeline = pipeline("depth-estimation", model=MODEL_ID)
        return self._pipeline

    def analyze_terrain(self, image_bytes: bytes) -> dict[str, Any]:
        image = Image.open(BytesIO(image_bytes)).convert("RGB")
        prepared = _resize_for_inference(image)
        prediction = self._load_model()(prepared)
        depth = np.asarray(prediction["depth"].convert("F"), dtype=np.float32)
        normalized = _normalize_for_display(depth)
        color_bgr = cv2.applyColorMap(normalized, cv2.COLORMAP_VIRIDIS)

        return {
            "stats": {
                "analysis_type": "relative_depth_visualization",
                "model_id": MODEL_ID,
                "model_license": MODEL_LICENSE,
                "input_size": {"width": prepared.width, "height": prepared.height},
                "relative_depth_min": float(np.nanmin(depth)),
                "relative_depth_max": float(np.nanmax(depth)),
                "limitation": BOUNDARY,
            },
            "safe_zones": [],
            "images": {"depth_map": _as_data_url(color_bgr)},
        }
