from __future__ import annotations

from io import BytesIO
from pathlib import Path

import numpy as np
import streamlit as st
from PIL import Image

from src.backend_adapter import BackendDepthClient
from src.local_depth_anything import MODEL_ID, MODEL_LICENSE, LocalDepthAnythingClient, RELATIVE_DEPTH_DISCLAIMER
from src.visualization import make_depth_visuals


ROOT = Path(__file__).parent


def read_upload(uploaded) -> tuple[np.ndarray, Image.Image]:
    image = Image.open(BytesIO(uploaded.getvalue())).convert("RGB")
    return np.asarray(image), image


@st.cache_resource(show_spinner=False)
def local_client() -> LocalDepthAnythingClient:
    return LocalDepthAnythingClient()


st.set_page_config(page_title="Depth Scout", page_icon="◌", layout="wide")
st.markdown(
    """
    <style>
      .stApp { background: #0c1322; color: #e8edf5; }
      .block-container { max-width: 1420px; padding-top: 2.1rem; }
      [data-testid="stSidebar"] { background: #111d31; }
      [data-testid="stSidebar"] label, [data-testid="stSidebar"] p, [data-testid="stSidebar"] span { color: #e8edf5 !important; }
      .tag { color: #89d7ff; letter-spacing: .14em; font-family: monospace; font-size: .78rem; font-weight: 700; }
      .title { font-size: 3.55rem; line-height: .94; letter-spacing: -.065em; margin: .24rem 0 .9rem; }
      .lead { max-width: 67ch; color: #b9c6d8; font-size: 1.08rem; }
      .boundary { background: #17283e; border: 1px solid #386185; border-left: 5px solid #70c8f5; padding: 1rem 1.1rem; border-radius: 10px; margin: .9rem 0 1.3rem; }
      .caption-card { background: #111d31; padding: .8rem .9rem; border: 1px solid #263f5f; border-radius: 9px; }
    </style>
    """,
    unsafe_allow_html=True,
)

with st.sidebar:
    st.markdown("## DEPTH SCOUT")
    st.caption("Relative-depth explorer · clean-room prototype")
    st.divider()
    engine = st.radio("Inference source", ["Local public checkpoint", "Future backend API"])
    backend_url = ""
    if engine == "Future backend API":
        backend_url = st.text_input("Backend base URL", placeholder="https://your-service.example")
    st.divider()
    st.markdown("### Model provenance")
    st.caption(f"**Model:** `{MODEL_ID}`\n\n**License:** {MODEL_LICENSE}\n\n**Status:** unmodified public checkpoint; no fine-tuning in this repository.")
    st.markdown("### Boundary")
    st.caption("The map is relative depth only. It does not measure Mars terrain, label hazards, or approve a landing site.")

st.markdown('<div class="tag">OPEN CHECKPOINT · EXPLORATORY VISUALIZATION · HUMAN INTERPRETATION REQUIRED</div>', unsafe_allow_html=True)
st.markdown('<h1 class="title">See relative structure.<br/>Not certainty.</h1>', unsafe_allow_html=True)
st.markdown(
    '<p class="lead">Depth Scout runs one openly licensed public checkpoint to produce a relative-depth visualization. It is a deliberately separate app with its own inference adapter, third-party notices, and a future backend boundary.</p>',
    unsafe_allow_html=True,
)
st.markdown(
    '<div class="boundary"><strong>Important:</strong> Depth Anything V2 Small is a public pre-trained model, not a Mars-calibrated instrument. Bright or dark regions are only relative model outputs within the uploaded image. Do not interpret them as elevation, physical distance, obstacle detection, or a safe/unsafe decision.</div>',
    unsafe_allow_html=True,
)

upload = st.file_uploader("Upload a PNG, JPG, or JPEG image", type=["png", "jpg", "jpeg"])
if upload is None:
    st.markdown('<div class="caption-card"><strong>How this app stays separate:</strong> it contains no MARSBOUND code, trained weights, UI components, or prepared Mars assets. Upload an image you have permission to use. On the first local run, the cited public checkpoint downloads from its official Hugging Face model page.</div>', unsafe_allow_html=True)
    st.stop()

try:
    image_rgb, display_image = read_upload(upload)
    if engine == "Local public checkpoint":
        with st.spinner("Loading the cited public checkpoint and estimating relative depth..."):
            result = local_client().infer(image_rgb)
    else:
        if not backend_url:
            st.warning("Provide a backend base URL, or switch back to local public-checkpoint mode.")
            st.stop()
        with st.spinner("Requesting relative depth from the configured backend..."):
            result = BackendDepthClient(backend_url).infer(image_rgb)
    depth_gray, depth_color = make_depth_visuals(result.relative_depth)
except Exception as error:
    st.error(f"Depth estimation could not complete: {error}")
    st.stop()

stats = st.columns(4)
stats[0].metric("Inference source", "Local" if result.source.startswith("local") else "Backend")
stats[1].metric("Model", "Depth Anything V2 Small" if result.model_id == MODEL_ID else result.model_id)
stats[2].metric("License", MODEL_LICENSE if result.model_id == MODEL_ID else "See backend")
stats[3].metric("Output", "Relative depth")

left, right = st.columns(2)
left.image(display_image, caption="Uploaded source image", width="stretch")
right.image(depth_color, caption="Relative-depth color visualization (normalized within this image)", width="stretch")

st.image(depth_gray, caption="Relative-depth grayscale view (display-normalized; not a physical measurement)", width="stretch")
st.markdown(
    f'<div class="boundary"><strong>Output boundary:</strong> {result.disclaimer}</div>',
    unsafe_allow_html=True,
)
st.markdown(
    f"**Credit:** This app uses the unmodified public checkpoint [{MODEL_ID}](https://huggingface.co/{MODEL_ID}) under {MODEL_LICENSE}. See the bundled `MODEL_PROVENANCE.md` and `API_CONTRACT.md` files in this repository for the model and future-backend details."
)
