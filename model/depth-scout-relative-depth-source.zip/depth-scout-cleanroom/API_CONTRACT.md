# Future backend integration contract

The Streamlit app uses a `DepthInferenceClient`-style boundary. Today, `LocalDepthAnythingClient` loads the public model locally. Later, selecting **Future backend API** in the app uses `BackendDepthClient` instead, without changing the UI visualization layer.

## Request

`POST /v1/relative-depth`

The request is multipart form data with one required field:

| Field | Type | Meaning |
|---|---|---|
| `image` | PNG or JPEG file | An image the user has permission to submit. |

## Response

```json
{
  "model_id": "depth-anything/Depth-Anything-V2-Small-hf",
  "relative_depth_url": "https://storage.example/results/abc.png",
  "disclaimer": "Relative-depth visualization only; not a physical measurement or safety decision."
}
```

The URL must point to a grayscale image whose values are only a displayable relative-depth representation. The backend must preserve model provenance, apply file-size and image-format validation, and return the limitation text. It must not describe the output as Mars terrain truth or landing certification.

## Backend move later

In a production backend, move `LocalDepthAnythingClient` behind this endpoint, cache the model once per worker, store the uploaded file and result in object storage, and return a short-lived result URL. The app already has `BackendDepthClient` for this contract.
