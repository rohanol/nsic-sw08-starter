"""Run the public checkpoint against an image and save visual outputs locally."""

from __future__ import annotations

import sys
from pathlib import Path

import numpy as np
from PIL import Image

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from src.local_depth_anything import LocalDepthAnythingClient
from src.visualization import make_depth_visuals


def main() -> None:
    if len(sys.argv) != 3:
        raise SystemExit("Usage: python scripts/run_model_check.py INPUT_IMAGE OUTPUT_DIRECTORY")
    input_path = Path(sys.argv[1])
    output_dir = Path(sys.argv[2])
    output_dir.mkdir(parents=True, exist_ok=True)
    image = Image.open(input_path).convert("RGB")
    result = LocalDepthAnythingClient().infer(np.asarray(image))
    gray, color = make_depth_visuals(result.relative_depth)
    Image.fromarray(gray).save(output_dir / "relative_depth_gray.png")
    Image.fromarray(color).save(output_dir / "relative_depth_color.png")
    print(f"model={result.model_id}")
    print(f"source={result.source}")
    print(f"shape={result.relative_depth.shape}")
    print(f"disclaimer={result.disclaimer}")


if __name__ == "__main__":
    main()
