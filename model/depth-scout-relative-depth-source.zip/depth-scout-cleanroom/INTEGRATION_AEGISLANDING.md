# AegisLanding backend handoff

This guide connects Depth Scout to the `rohanol/nsic-sw08-starter` backend without changing its existing route contract.

## Why this fits the current backend

The starter backend already routes `POST /api/v1/assessments` requests with `engine=ml` to `MLElevationAnalyzer.analyze_terrain(contents)`. The archive provides a direct replacement for that currently empty class. It accepts raw image bytes and returns the `stats`, `safe_zones`, and `images` keys that the existing `AssessmentResponse` expects.

| Target repository path | Archive file | Action |
|---|---|---|
| `backend/app/ml_engine.py` | `integration/aegislanding_ml_engine.py` | Replace the starter placeholder after model approval. |
| `backend/requirements.txt` | `requirements-backend.txt` | Append these packages, preserving the backend’s existing dependencies. |
| `model/` | `depth-scout-relative-depth-source.zip` | Keep the archive and provenance note for auditability. |

## Three integration steps

First, copy `integration/aegislanding_ml_engine.py` over `backend/app/ml_engine.py`. Second, append the entries in `requirements-backend.txt` to the existing backend dependency file and install them. Third, run the existing backend and submit an authenticated request with `engine=ml` to the existing assessment endpoint.

```bash
cd backend
python3 -m pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

The current endpoint already receives a multipart field named `file`, requires `engine=ml`, validates JPEG/PNG/WEBP MIME types, and limits upload size to 10 MB. The drop-in adapter respects that flow and additionally caps model input width at 1600 pixels.

## Backend smoke test

After the backend starts, set the API key locally rather than placing it in source control. Then use the following request with a JPEG or PNG that you are authorized to use:

```bash
export AEGIS_API_KEY='set-this-locally-to-the-backend-X-Mission-Control-Key'

curl --fail --silent --show-error \
  -X POST 'http://127.0.0.1:8000/api/v1/assessments' \
  -H "X-Mission-Control-Key: ${AEGIS_API_KEY}" \
  -F 'engine=ml' \
  -F 'file=@../data/sample-terrain.jpg;type=image/jpeg' \
  | python3 -m json.tool
```

The first successful call may take longer because it downloads the cited public checkpoint. A passing response contains `stats.model_id`, `stats.model_license`, `stats.limitation`, an empty `safe_zones` list, and `images.depth_map` as an image data URL. A nonempty `safe_zones` list must come from a separately documented team-built risk layer, not from this relative-depth adapter.

## Response behavior

The ML response returns a `depth_map` image data URL plus `model_id`, `model_license`, input dimensions, and relative-depth range. It intentionally returns an empty `safe_zones` list. Relative depth by itself cannot establish a safe landing zone; add a separate, team-built risk layer only after defining and documenting its inputs and limitations.

> The checkpoint output is an exploratory relative-depth visualization—not a Mars-calibrated distance, elevation, slope, hazard class, risk score, or safety certification.

## Citation and approval

Use only `depth-anything/Depth-Anything-V2-Small-hf`, which is identified by its official model card as Apache-2.0. Attribute the model and retain the limitation text. Obtain written NSIC organizer approval before activating pre-trained weights in the event submission.

## References

[1] [Depth Anything V2 Small official model card](https://huggingface.co/depth-anything/Depth-Anything-V2-Small-hf)

[2] [Depth Anything V2 official repository](https://github.com/DepthAnything/Depth-Anything-V2)
