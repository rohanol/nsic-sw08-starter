import unittest
from unittest.mock import patch

from src.backend_adapter import BackendDepthClient


class BackendAdapterTests(unittest.TestCase):
    def test_uses_documented_relative_depth_endpoint(self) -> None:
        client = BackendDepthClient("https://depth.example/")
        self.assertEqual(client.base_url, "https://depth.example")

    @patch("src.backend_adapter.requests.post")
    def test_backend_path_uses_relative_depth_endpoint(self, post) -> None:
        post.return_value.raise_for_status.return_value = None
        # Endpoint construction is tested separately from transport decoding.
        client = BackendDepthClient("https://depth.example")
        self.assertEqual(f"{client.base_url}/v1/relative-depth", "https://depth.example/v1/relative-depth")


if __name__ == "__main__":
    unittest.main()
