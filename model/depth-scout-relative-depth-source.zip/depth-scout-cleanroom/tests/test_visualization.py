import unittest

import numpy as np

from src.visualization import make_depth_visuals, normalize_relative_depth


class VisualizationTests(unittest.TestCase):
    def test_normalization_spans_display_range(self) -> None:
        depth = np.array([[2.0, 4.0], [6.0, 8.0]], dtype=np.float32)
        normalized = normalize_relative_depth(depth)
        self.assertEqual(normalized.min(), 0)
        self.assertEqual(normalized.max(), 255)

    def test_visuals_preserve_depth_shape(self) -> None:
        depth = np.array([[1.0, 2.0, 3.0], [4.0, 5.0, 6.0]], dtype=np.float32)
        grayscale, color = make_depth_visuals(depth)
        self.assertEqual(grayscale.shape, (2, 3))
        self.assertEqual(color.shape, (2, 3, 3))


if __name__ == "__main__":
    unittest.main()
