# Model provenance and attribution

Depth Scout uses **only** the unmodified public checkpoint `depth-anything/Depth-Anything-V2-Small-hf`. It is loaded locally through the Transformers depth-estimation interface. This repository does not train, fine-tune, re-export, or rename the checkpoint.

| Item | Disclosure |
|---|---|
| Model | Depth Anything V2 Small — Transformers version |
| Exact identifier | `depth-anything/Depth-Anything-V2-Small-hf` |
| License | Apache-2.0 |
| Authors | Lihe Yang, Bingyi Kang, Zilong Huang, Zhen Zhao, Xiaogang Xu, Jiashi Feng, Hengshuang Zhao |
| Official model card | https://huggingface.co/depth-anything/Depth-Anything-V2-Small-hf |
| Official source repository | https://github.com/DepthAnything/Depth-Anything-V2 |
| App use | Exploratory **relative-depth** visualization only |

> This model output is not calibrated for Mars. It must not be represented as a measurement of elevation, distance, slope, obstacle likelihood, or landing safety.

The official project states that the Small model is Apache-2.0, while its Base, Large, and Giant variants are CC-BY-NC-4.0. This application deliberately uses the Small checkpoint only. [1]

## Citation

```bibtex
@misc{yang2024depth,
  title={Depth Anything V2},
  author={Lihe Yang and Bingyi Kang and Zilong Huang and Zhen Zhao and Xiaogang Xu and Xiaogang Xu and Jiashi Feng and Hengshuang Zhao},
  year={2024},
  eprint={2406.09414}
}
```

## References

[1] [Depth Anything V2 official repository](https://github.com/DepthAnything/Depth-Anything-V2)
