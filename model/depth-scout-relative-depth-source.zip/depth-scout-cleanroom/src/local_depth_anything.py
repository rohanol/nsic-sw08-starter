"""Local adapter for the unmodified Depth Anything V2 Small checkpoint."""

from __future__ import annotations

import os

import numpy as np
from PIL import Image

from .contracts import DepthResult


MODEL_ID = "depth-anything/Depth-Anything-V2-Small-hf"
MODEL_LICENSE = "Apache-2.0"
RELATIVE_DEPTH_DISCLAIMER = (
    "This is a relative-depth visualization from a public pre-trained model. "
    "It is not a measured Mars elevation, distance, slope, hazard label, or landing decision."
)


class LocalDepthAnythingClient:
    """Lazily loads the cited model so importing the app does not download weights."""

    def __init__(self, model_id: str = MODEL_ID) -> None:
        self.model_id = model_id
        self._pipeline = None

    def _load_pipeline(self):
        if self._pipeline is None:
            # This is an unmodified public checkpoint. `local_files_only` can be
            # enabled by setting DEPTH_SCOUT_OFFLINE=1 after an initial download.
            from transformers import pipeline

            offline = os.getenv("DEPTH_SCOUT_OFFLINE", "0") == "1"
            self._pipeline = pipeline(
                task="depth-estimation",
                model=self.model_id,
                local_files_only=offline,
            )
        return self._pipeline

    def infer(self, image_rgb: np.ndarray) -> DepthResult:
        if image_rgb.ndim != 3 or image_rgb.shape[2] != 3:
            raise ValueError("Depth Scout expects an RGB image with three channels.")

        prediction = self._load_pipeline()(Image.fromarray(image_rgb))
        depth_image = prediction["depth"].convert("F")
        depth = np.asarray(depth_image, dtype=np.float32)
        return DepthResult(
            relative_depth=depth,
            model_id=self.model_id,
            source="local_unmodified_public_checkpoint",
            disclaimer=RELATIVE_DEPTH_DISCLAIMER,
        )
