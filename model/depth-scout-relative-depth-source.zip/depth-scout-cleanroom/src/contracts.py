"""Shared, model-agnostic contracts for Depth Scout inference."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol

import numpy as np


@dataclass(frozen=True)
class DepthResult:
    """A relative-depth result, never a measured physical distance."""

    relative_depth: np.ndarray
    model_id: str
    source: str
    disclaimer: str


class DepthInferenceClient(Protocol):
    def infer(self, image_rgb: np.ndarray) -> DepthResult:
        """Return a relative-depth map with the same image orientation as input."""
        ...
