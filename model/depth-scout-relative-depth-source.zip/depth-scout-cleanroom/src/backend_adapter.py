"""Optional future HTTP adapter; no backend is required for local use today."""

from __future__ import annotations

from io import BytesIO

import numpy as np
import requests
from PIL import Image

from .contracts import DepthResult
from .local_depth_anything import RELATIVE_DEPTH_DISCLAIMER


class BackendDepthClient:
    """Calls a future service implementing the API documented in API_CONTRACT.md."""

    def __init__(self, base_url: str, timeout_seconds: int = 60) -> None:
        self.base_url = base_url.rstrip("/")
        self.timeout_seconds = timeout_seconds

    def infer(self, image_rgb: np.ndarray) -> DepthResult:
        buffer = BytesIO()
        Image.fromarray(image_rgb).save(buffer, format="PNG")
        response = requests.post(
            f"{self.base_url}/v1/relative-depth",
            files={"image": ("upload.png", buffer.getvalue(), "image/png")},
            timeout=self.timeout_seconds,
        )
        response.raise_for_status()
        payload = response.json()
        depth_url = payload.get("relative_depth_url")
        if not isinstance(depth_url, str):
            raise ValueError("Backend response did not provide `relative_depth_url`.")

        depth_response = requests.get(depth_url, timeout=self.timeout_seconds)
        depth_response.raise_for_status()
        depth = np.asarray(Image.open(BytesIO(depth_response.content)).convert("F"), dtype=np.float32)
        return DepthResult(
            relative_depth=depth,
            model_id=str(payload.get("model_id", "unspecified_backend_model")),
            source="backend_api",
            disclaimer=str(payload.get("disclaimer", RELATIVE_DEPTH_DISCLAIMER)),
        )
