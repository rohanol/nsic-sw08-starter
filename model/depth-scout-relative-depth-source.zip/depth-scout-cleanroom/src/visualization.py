"""Display helpers that preserve the model output as a relative visualization."""

from __future__ import annotations

import cv2
import numpy as np


def normalize_relative_depth(depth: np.ndarray) -> np.ndarray:
    """Map any finite relative-depth array to 8-bit display values."""
    finite = depth[np.isfinite(depth)]
    if finite.size == 0:
        raise ValueError("Relative-depth output contains no finite values.")
    low, high = float(finite.min()), float(finite.max())
    if high - low < 1e-9:
        return np.zeros(depth.shape, dtype=np.uint8)
    scaled = np.clip((depth - low) / (high - low), 0.0, 1.0)
    return np.uint8(scaled * 255)


def make_depth_visuals(depth: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Return grayscale and color-mapped RGB visualizations for relative depth."""
    normalized = normalize_relative_depth(depth)
    color_bgr = cv2.applyColorMap(normalized, cv2.COLORMAP_VIRIDIS)
    return normalized, cv2.cvtColor(color_bgr, cv2.COLOR_BGR2RGB)
