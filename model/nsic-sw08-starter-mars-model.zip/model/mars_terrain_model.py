"""Standalone AI4Mars MSL terrain-segmentation model.

This module contains inference only. It does not start a server, import a
frontend, or require a backend. The learned parameters live in the adjacent
``ai4mars_msl_multiprototype_v3.json`` artifact.

The model is a transparent nearest-prototype classifier. Each 256x256 grayscale
pixel is represented by four local features—intensity, gradient, local
standard deviation, and curvature—and assigned to the nearest learned
prototype in normalized feature space.
"""
from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path
from typing import Any

import cv2
import numpy as np

DEFAULT_ARTIFACT = Path(__file__).with_name("ai4mars_msl_multiprototype_v3.json")
MODEL_SIZE = (256, 256)
TERRAIN_CLASSES = (
    {"id": 0, "name": "soil", "color": (183, 133, 84)},
    {"id": 1, "name": "bedrock", "color": (104, 140, 180)},
    {"id": 2, "name": "sand", "color": (221, 186, 77)},
    {"id": 3, "name": "big_rock", "color": (217, 82, 65)},
)


@dataclass(frozen=True)
class TerrainPrediction:
    """Inference output for one image.

    ``mask`` and ``confidence`` are returned at the input image resolution.
    Confidence is a nearest-prototype margin, not a calibrated probability.
    ``class_distribution`` contains the fraction of pixels assigned to each
    terrain class and sums to one, up to floating-point rounding.
    """

    mask: np.ndarray
    confidence: np.ndarray
    class_distribution: dict[str, float]
    model_version: str
    input_shape: tuple[int, int]

    def to_dict(self, include_arrays: bool = False) -> dict[str, Any]:
        """Return JSON-friendly metadata, optionally including array values."""
        result: dict[str, Any] = {
            "model_version": self.model_version,
            "input_shape": list(self.input_shape),
            "class_distribution": self.class_distribution,
            "confidence": {
                "mean": float(self.confidence.mean()),
                "min": float(self.confidence.min()),
                "max": float(self.confidence.max()),
            },
        }
        if include_arrays:
            result["mask"] = self.mask.tolist()
            result["confidence_map"] = self.confidence.tolist()
        return result


class MarsTerrainModel:
    """Load and run the pretrained AI4Mars MSL terrain model."""

    def __init__(self, artifact_path: str | Path = DEFAULT_ARTIFACT) -> None:
        artifact = Path(artifact_path)
        with artifact.open("r", encoding="utf-8") as handle:
            payload = json.load(handle)

        self.artifact_path = artifact
        self.version = str(payload["version"])
        self.feature_names = tuple(payload["featureNames"])
        self.feature_mean = np.asarray(payload["featureMean"], dtype=np.float32)
        self.feature_scale = np.asarray(payload["featureScale"], dtype=np.float32)
        self.prototypes_per_class = int(payload["prototypesPerClass"])
        self.centroids = np.asarray(payload["centroids"], dtype=np.float32)
        self.classes = tuple(payload.get("classes", TERRAIN_CLASSES))

        if self.centroids.ndim != 2 or self.centroids.shape[1] != 4:
            raise ValueError("The artifact must contain an N x 4 centroid matrix")
        if len(self.centroids) != self.prototypes_per_class * len(self.classes):
            raise ValueError("Centroid count does not match classes and prototypes")
        if self.feature_mean.shape != (4,) or self.feature_scale.shape != (4,):
            raise ValueError("Feature normalization arrays must each contain four values")
        if np.any(self.feature_scale <= 0):
            raise ValueError("Feature scales must be positive")

    @classmethod
    def default(cls) -> "MarsTerrainModel":
        """Load the pretrained artifact shipped beside this module."""
        return cls(DEFAULT_ARTIFACT)

    @property
    def metadata(self) -> dict[str, Any]:
        """Expose model metadata without exposing mutable NumPy arrays."""
        return {
            "version": self.version,
            "feature_names": list(self.feature_names),
            "prototypes_per_class": self.prototypes_per_class,
            "class_names": [item["name"] for item in self.classes],
            "training_pairs": 538,
        }

    @staticmethod
    def _to_grayscale(image: np.ndarray | str | Path) -> np.ndarray:
        if isinstance(image, (str, Path)):
            loaded = cv2.imread(str(image), cv2.IMREAD_UNCHANGED)
            if loaded is None:
                raise FileNotFoundError(f"Could not read image: {image}")
            image = loaded

        array = np.asarray(image)
        if array.ndim == 3:
            if array.shape[2] == 4:
                array = cv2.cvtColor(array, cv2.COLOR_BGRA2GRAY)
            elif array.shape[2] == 3:
                array = cv2.cvtColor(array, cv2.COLOR_RGB2GRAY)
            else:
                raise ValueError("Image must have one, three, or four channels")
        if array.ndim != 2 or array.size == 0:
            raise ValueError("Image must be a non-empty 2-D grayscale array")
        if not np.issubdtype(array.dtype, np.number):
            raise TypeError("Image values must be numeric")

        array = array.astype(np.float32, copy=False)
        if not np.isfinite(array).all():
            raise ValueError("Image contains NaN or infinite values")
        if array.max() > 1.0:
            array /= 255.0
        return np.clip(array, 0.0, 1.0)

    @staticmethod
    def extract_features(image_256: np.ndarray) -> np.ndarray:
        """Extract the four features used during training from a [0, 1] image."""
        image = np.asarray(image_256, dtype=np.float32)
        left, right = np.roll(image, 1, axis=1), np.roll(image, -1, axis=1)
        top, bottom = np.roll(image, 1, axis=0), np.roll(image, -1, axis=0)
        gradient = np.minimum(1.0, np.hypot(right - left, bottom - top))
        mean = cv2.GaussianBlur(image, (0, 0), 2.0)
        mean_square = cv2.GaussianBlur(image * image, (0, 0), 2.0)
        local_std = np.sqrt(np.maximum(mean_square - mean * mean, 0.0))
        curvature = np.abs(cv2.Laplacian(image, cv2.CV_32F, ksize=3)).clip(0.0, 1.0)
        return np.stack((image, gradient, local_std, curvature), axis=-1).reshape(-1, 4)

    def _predict_256(self, image_256: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
        raw = self.extract_features(image_256)
        normalized = (raw - self.feature_mean) / self.feature_scale
        center_norm = np.sum(self.centroids * self.centroids, axis=1)
        labels: list[np.ndarray] = []
        confidences: list[np.ndarray] = []

        for start in range(0, len(normalized), 8192):
            part = normalized[start : start + 8192]
            distances = (
                np.sum(part * part, axis=1, keepdims=True)
                + center_norm[None, :]
                - 2.0 * (part @ self.centroids.T)
            )
            nearest_two = np.partition(distances, kth=1, axis=1)[:, :2]
            best = np.min(nearest_two, axis=1)
            second = np.max(nearest_two, axis=1)
            labels.append((np.argmin(distances, axis=1) // self.prototypes_per_class).astype(np.uint8))
            margin = (second - best) / (second + 1e-8)
            confidences.append(np.clip(margin, 0.0, 1.0).astype(np.float32))

        return (
            np.concatenate(labels).reshape(MODEL_SIZE[1], MODEL_SIZE[0]),
            np.concatenate(confidences).reshape(MODEL_SIZE[1], MODEL_SIZE[0]),
        )

    def predict(self, image: np.ndarray | str | Path) -> TerrainPrediction:
        """Segment a grayscale/RGB image and return a structured prediction."""
        grayscale = self._to_grayscale(image)
        input_shape = tuple(int(value) for value in grayscale.shape)
        resized = cv2.resize(grayscale, MODEL_SIZE, interpolation=cv2.INTER_AREA)
        mask_256, confidence_256 = self._predict_256(resized)
        if input_shape != MODEL_SIZE[::-1]:
            mask = cv2.resize(mask_256, input_shape[::-1], interpolation=cv2.INTER_NEAREST)
            confidence = cv2.resize(confidence_256, input_shape[::-1], interpolation=cv2.INTER_LINEAR)
        else:
            mask, confidence = mask_256, confidence_256

        total = float(mask.size)
        distribution = {
            item["name"]: float(np.count_nonzero(mask == item["id"]) / total)
            for item in self.classes
        }
        return TerrainPrediction(
            mask=mask,
            confidence=confidence,
            class_distribution=distribution,
            model_version=self.version,
            input_shape=input_shape,
        )

    def colorize(self, mask: np.ndarray) -> np.ndarray:
        """Convert a class mask to an RGB visualization array."""
        output = np.zeros((*mask.shape, 3), dtype=np.uint8)
        for item in self.classes:
            output[mask == item["id"]] = item["color"]
        return output


__all__ = ["MarsTerrainModel", "TerrainPrediction", "TERRAIN_CLASSES"]
