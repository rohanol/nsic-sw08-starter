"""Run model smoke tests without requiring a test runner dependency."""
from .test_mars_terrain_model import (
    test_default_model_metadata_and_artifact,
    test_predict_accepts_rgb_input_and_colorizes_mask,
    test_predict_restores_grayscale_input_shape,
)

for test in (
    test_default_model_metadata_and_artifact,
    test_predict_restores_grayscale_input_shape,
    test_predict_accepts_rgb_input_and_colorizes_mask,
):
    test()
    print(f"PASS {test.__name__}")
