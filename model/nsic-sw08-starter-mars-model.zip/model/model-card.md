# Model Card — AI4Mars MSL Multi-Prototype Terrain Model

## Model name

`ai4mars-msl-multiprototype-v3`

## Intended use

This model performs **semantic terrain segmentation** on Mars rover imagery for a prototype decision-support workflow. It labels pixels as soil, bedrock, sand, or big rock. The output is advisory and must not be represented as a flight-control command, landing certification, or autonomous safety decision.

## Inputs

The model accepts a grayscale, RGB, or RGBA image as a file path or NumPy array. Numeric arrays may use either `[0, 1]` or `[0, 255]` intensity ranges. Images are converted to grayscale, resized to `256 × 256`, and returned to the original spatial resolution after inference.

| Feature | Definition | Validity behavior |
| --- | --- | --- |
| `intensity` | Grayscale intensity normalized to `[0, 1]`. | Input values are clipped after range conversion. |
| `gradient` | Central-difference magnitude, clipped to `[0, 1]`. | Computed from the resized image. |
| `local_std` | Local standard deviation from Gaussian-smoothed first and second moments. | Numerical negative round-off is clamped to zero before the square root. |
| `curvature` | Absolute `3 × 3` Laplacian response, clipped to `[0, 1]`. | Computed from the resized image. |

Missing, nonnumeric, empty, NaN, infinite, or unreadable input is rejected with an exception. The model does not infer georeferencing, illumination quality, rover pose, or sensor provenance.

## Output

`MarsTerrainModel.predict()` returns a `TerrainPrediction` containing the class mask, per-pixel prototype-margin confidence, class distribution, model version, and original input shape. The class IDs are:

| ID | Class | Visualization color (RGB) |
| ---: | --- | --- |
| 0 | Soil | `(183, 133, 84)` |
| 1 | Bedrock | `(104, 140, 180)` |
| 2 | Sand | `(221, 186, 77)` |
| 3 | Big rock | `(217, 82, 65)` |

Confidence is the relative gap between the nearest and second-nearest prototype distances. It is a ranking signal, **not a calibrated probability**.

## Model design

The model is a transparent nearest-prototype classifier. It uses 24 learned prototypes for each of the four classes, for 96 centroids total. Feature normalization statistics and learned centroids are stored in `ai4mars_msl_multiprototype_v3.json`; there are no hidden network weights or server calls.

## Training and evaluation context

The artifact was trained on 538 matched AI4Mars MSL image-label pairs in the referenced Mars-image analysis work. On that work’s held-out split, the model reported 35.62% pixel accuracy and 32.81% macro F1. The class F1 values were 43.73% for soil, 20.56% for bedrock, 29.64% for sand, and 37.30% for big rock. These values are historical experiment results, not a guarantee for new imagery.

## Security and reliability

Treat all image inputs as untrusted. Validate file type, dimensions, provenance, and sensor metadata in the calling application. Keep model and dataset versions in audit logs. Do not treat a single mask, confidence map, or class distribution as sufficient evidence for a landing decision. Use independent terrain, slope, illumination, and uncertainty checks before any operational recommendation.

## Limitations

The model is trained on MSL rover imagery and may not transfer to other cameras, terrain domains, seasons, illumination conditions, or planetary bodies. It does not estimate physical slope, elevation, rock height, traversability, or landing dynamics. The prototype-margin confidence is not calibrated, and the current evaluation is not a flight-validation campaign. The model should remain a transparent research baseline until it is revalidated on representative, expert-labeled, unseen data.
