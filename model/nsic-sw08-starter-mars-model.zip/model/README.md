# Standalone Mars Terrain Model

This directory contains **model-only inference code** for semantic terrain segmentation of Mars rover imagery. It has no frontend, backend, API server, or application startup code. The model can be imported by another part of the repository when the team is ready to connect it.

## Files

| File | Purpose |
| --- | --- |
| `mars_terrain_model.py` | Inference implementation and output data classes. |
| `ai4mars_msl_multiprototype_v3.json` | Embedded learned parameters: normalization statistics and 96 centroids. |
| `__init__.py` | Direct package exports. |
| `model-card.md` | Intended use, evaluation context, and limitations. |

## Usage

Install the only runtime dependency used by the model with `pip install numpy opencv-python`, then import it from the repository root:

```python
from pathlib import Path
import cv2
from model import MarsTerrainModel

model = MarsTerrainModel.default()
prediction = model.predict(Path("mars_rover_image.jpg"))

# Class IDs: 0 soil, 1 bedrock, 2 sand, 3 big_rock.
mask = prediction.mask
print(prediction.class_distribution)
print(prediction.to_dict())

# Optional RGB visualization; write it with OpenCV if desired.
visualization_rgb = model.colorize(mask)
cv2.imwrite("terrain_mask.png", cv2.cvtColor(visualization_rgb, cv2.COLOR_RGB2BGR))
```

`predict()` accepts a path or a NumPy array. Arrays can be grayscale in `[0, 1]` or `[0, 255]`, or RGB/RGBA numeric arrays. The image is resized internally to `256 × 256` for inference and the class mask is resized back to the original resolution.

## Model behavior

The classifier uses four local features per pixel: normalized intensity, a local gradient magnitude, Gaussian-window local standard deviation, and absolute Laplacian curvature. Each feature vector is normalized with training statistics and assigned to the nearest one of 96 learned centroids. There are 24 prototypes per terrain class. The returned confidence is a nearest-prototype distance margin and **is not a calibrated probability**.

The artifact is the `ai4mars-msl-multiprototype-v3` model developed in the referenced Mars-image analysis work. It was trained on 538 matched AI4Mars MSL pairs. The prior held-out comparison reported 35.62% pixel accuracy and 32.81% macro F1, with rare-class F1 scores of 29.64% for sand and 37.30% for big rock. These figures describe the prior evaluation split and should not be interpreted as flight-readiness or a safety guarantee.

## Integration boundary

Keep this package independent from the backend and frontend. An application layer should call `MarsTerrainModel.predict()`, serialize `TerrainPrediction.to_dict()`, and decide separately how to store or display masks. The model must remain advisory and must not be used as a flight-control command or safety certification.
