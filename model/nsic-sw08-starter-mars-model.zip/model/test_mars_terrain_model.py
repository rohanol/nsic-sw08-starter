from __future__ import annotations

import numpy as np

from model import MarsTerrainModel


def test_default_model_metadata_and_artifact() -> None:
    model = MarsTerrainModel.default()
    assert model.version == "ai4mars-msl-multiprototype-v3"
    assert model.centroids.shape == (96, 4)
    assert model.prototypes_per_class == 24


def test_predict_restores_grayscale_input_shape() -> None:
    model = MarsTerrainModel.default()
    image = np.linspace(0, 255, 96 * 128, dtype=np.float32).reshape(96, 128)
    prediction = model.predict(image)
    assert prediction.mask.shape == image.shape
    assert prediction.confidence.shape == image.shape
    assert set(np.unique(prediction.mask)).issubset({0, 1, 2, 3})
    assert abs(sum(prediction.class_distribution.values()) - 1.0) < 1e-6


def test_predict_accepts_rgb_input_and_colorizes_mask() -> None:
    model = MarsTerrainModel.default()
    image = np.zeros((64, 80, 3), dtype=np.uint8)
    image[:, :40] = (40, 40, 40)
    image[:, 40:] = (220, 220, 220)
    prediction = model.predict(image)
    visualization = model.colorize(prediction.mask)
    assert prediction.mask.shape == (64, 80)
    assert visualization.shape == (64, 80, 3)
    assert visualization.dtype == np.uint8
