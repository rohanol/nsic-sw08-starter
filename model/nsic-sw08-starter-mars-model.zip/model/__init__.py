"""Standalone Mars terrain model package."""

from .mars_terrain_model import MarsTerrainModel, TERRAIN_CLASSES, TerrainPrediction

__all__ = ["MarsTerrainModel", "TerrainPrediction", "TERRAIN_CLASSES"]
